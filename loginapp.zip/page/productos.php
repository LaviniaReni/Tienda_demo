<?php
session_start();
require "includes/db.php";

// Verificar login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$titulo = "Productos";
include __DIR__ . "/../includes/head.php";
include __DIR__ . "/../includes/header.php";?>

<div class="login">
  <div class="login__card">
    <h1 class="login__title">Productos Disponibles</h1>
    <div class="productos-grid">
      <?php
      $sql = "SELECT * FROM productos";
      $res = $conn->query($sql);

      if ($res && $res->num_rows > 0):
          while ($row = $res->fetch_assoc()):
      ?>
          <div class="producto-card">
              <a href="producto.php?id=<?php echo $row['id']; ?>">
                  <?php if (!empty($row['imagen'])): ?>
                      <img src="<?php echo htmlspecialchars($row['imagen']); ?>" alt="<?php echo htmlspecialchars($row['nombre']); ?>">
                  <?php endif; ?>
              </a>
              <h3>
                  <a href="producto.php?id=<?php echo $row['id']; ?>" style="color:#111827; text-decoration:none;">
                      <?php echo htmlspecialchars($row['nombre']); ?>
                  </a>
              </h3>
              <p><?php echo htmlspecialchars(substr($row['descripcion'], 0, 60)) . '...'; ?></p>
              <p><strong>$<?php echo number_format($row['precio'], 2); ?></strong></p>
              <p>Stock: <?php echo (int)$row['stock']; ?></p>

              <form method="post" action="agregar_carrito.php">
                  <input type="hidden" name="producto_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" class="btn-agregar">Agregar al carrito</button>
              </form>
          </div>
      <?php
          endwhile;
      else:
          echo '<p>No hay productos disponibles.</p>';
      endif;
      ?>
    </div>
    <p class="login__register"><a href="index.php" class="login__link">Volver al inicio</a></p>
  </div>
</div>

<?php include "includes/footer.php"; ?>
