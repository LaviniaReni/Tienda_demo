document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".header__menu-toggle");
  const nav = document.querySelector(".nav__list");

  if (!toggle || !nav) return;

  // Estados iniciales accesibles
  toggle.setAttribute("aria-expanded", "false");
  nav.setAttribute("aria-hidden", "true");

  // Abrir/cerrar menú
  toggle.addEventListener("click", () => {
    const isActive = nav.classList.toggle("is-active");
    toggle.setAttribute("aria-expanded", String(isActive));
    nav.setAttribute("aria-hidden", String(!isActive));
  });

  // Cerrar menú al hacer clic fuera
  document.addEventListener("click", (e) => {
    if (
      nav.classList.contains("is-active") &&
      !nav.contains(e.target) &&
      !toggle.contains(e.target)
    ) {
      nav.classList.remove("is-active");
      toggle.setAttribute("aria-expanded", "false");
      nav.setAttribute("aria-hidden", "true");
    }
  });

  // Cerrar menú con tecla ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && nav.classList.contains("is-active")) {
      nav.classList.remove("is-active");
      toggle.setAttribute("aria-expanded", "false");
      nav.setAttribute("aria-hidden", "true");
      toggle.focus(); // Devuelve el foco al botón
    }
  });
});
