<header class="header">
  <div class="header__container">

    <!-- BRAND -->
    <a href="index.php" class="header__brand" aria-label="Ir a inicio">

      <div class="header__logo">

        <img src="/assets/icons/logo.png" alt="Logo de LoginApp">

      </div>
    
      <div class="header__text">

        <h1 class="header__title">LoginApp</h1>
        <p class="header__subtitle">Tienda online</p>

      </div>

    </a>
  
    <!-- SEARCH -->
    <form class="search" action="buscar.php" method="get">
      <input class="search__input" type="text" name="q" placeholder="Buscar productos...">
      <button class="search__button" type="submit">
        <img src="/assets/icons/icon_lupa.svg" alt="Buscar" width="18" height="18">
      </button>
    </form>

    <!-- NAV -->
    <nav class="nav">
      <ul class="nav__list" id="menu">
        <li><a href="index.php" class="nav__link">
          <img src="/assets/icons/icon_home.svg" alt="Inicio" width="18" height="18"> Inicio
        </a></li>
        <li><a href="/page/productos.php" class="nav__link">
          <img src="/assets/icons/icon_box.svg" alt="Productos" width="18" height="18"> Productos
        </a></li>
        <li><a href="/page/contacto.php" class="nav__link">
          <img src="/assets/icons/icon_mail.svg" alt="Contacto" width="18" height="18"> Contacto
        </a></li>
      </ul>
    </nav>

    <!-- ACTIONS -->
    <div class="actions">
      <a href="carrito.php" class="actions__btn">
        <img src="/assets/icons/icon_cart.svg" alt="Carrito" width="20" height="20">
        <span class="actions__cart-count">0</span>
      </a>
      <a href="login.php" class="actions__btn">
        <img src="/assets/icons/icon_user.svg" alt="Usuario" width="20" height="20">
      </a>
    </div>

    <!-- MENU TOGGLE (MOBILE) -->
    <button class="header__menu-toggle" aria-label="Abrir menú">
      <img src="/assets/icons/icon_menu.svg" alt="Menú" width="22" height="22">
    </button>

  </div>
</header>
