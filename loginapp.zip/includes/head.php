<?php
// head.php
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- SEO -->
    <meta name="description" content="LoginApp - Tu tienda online para comprar productos al mejor precio.">
    <meta name="author" content="LoginApp">

    <!-- Favicon -->
    <link rel="icon" href="/assets/favicon.ico" sizes="any">
    <link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
    <link rel="apple-touch-icon" href="/assets/favicon.png">

    <!-- Estilos globales -->
    <link rel="stylesheet" href="/css/main.css">


    <!-- Script global -->
    <script src="/js/header.js" defer></script>

    <!-- Título dinámico -->
    <title><?php echo isset($pageTitle) ? $pageTitle . " | LoginApp" : "LoginApp"; ?></title>
</head>
